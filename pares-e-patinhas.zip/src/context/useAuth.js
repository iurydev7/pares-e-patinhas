import { useContext } from 'react'
import { AuthContext } from './AuthContext'

export function useAuth() {
  const contexto = useContext(AuthContext)

  if (!contexto) {
    throw new Error('useAuth precisa ser usado dentro do <AuthProvider>.')
  }

  return contexto
}